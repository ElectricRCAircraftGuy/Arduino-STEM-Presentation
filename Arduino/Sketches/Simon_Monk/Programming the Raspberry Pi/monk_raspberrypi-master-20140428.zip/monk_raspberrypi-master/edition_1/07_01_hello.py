#07_01_hello.py

from tkinter import *

root = Tk()

Label(root, text='Hello World').pack()

root.mainloop()
