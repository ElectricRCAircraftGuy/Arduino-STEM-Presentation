#04_03_hello_n
def say_hello(n):
	for x in range(0, n):
		print('Hello')
		
say_hello(5)