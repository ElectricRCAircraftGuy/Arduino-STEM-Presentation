#03_01_dice
import random
for x in range(1, 11):
	random_number = random.randint(1, 6)
	print(random_number)