#04_02_polite_function
def make_polite(sentence):
	polite_sentence = sentence + ' please'
	return polite_sentence

print(make_polite('Pass the salt'))
	