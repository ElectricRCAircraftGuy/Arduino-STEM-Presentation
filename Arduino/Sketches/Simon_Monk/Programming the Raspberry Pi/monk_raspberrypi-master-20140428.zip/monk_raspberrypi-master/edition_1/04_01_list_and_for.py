#04_01_list_and_for
list = [1, 'one', 2, True]
for item in list:
	print(item)
