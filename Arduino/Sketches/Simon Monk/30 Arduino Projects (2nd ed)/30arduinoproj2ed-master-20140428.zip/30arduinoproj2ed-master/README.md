30arduinoproj2ed
================

The code for the second edition of the book '30 Arduino Projects for the Evil Genius' by Simon Monk.