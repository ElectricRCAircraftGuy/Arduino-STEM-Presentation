ArduinoNextSteps
================

Arduino sketches and other source code for the book 'Programming Arduino: Next Steps' by Simon Monk.

See http://www.simonmonk.org for details.

Place the ArduinoNextSteps folder into your Arduino IDE sketches folder.