hacking_electronics
===================

The code used in the book Hacking Electronics, by SImon Monk.